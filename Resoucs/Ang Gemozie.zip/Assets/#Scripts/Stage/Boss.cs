﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Boss : MonoBehaviour
{
    public GameObject Claer;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //if (GameObject.Find("Boss") == null)
        //{
        //    Claer.SetActive(true);
        //    Destroy(GameObject.Find("Player"));

        //    GameObject.Find("InGame").transform.GetChild(8).gameObject.SetActive(false);
        //    AudioManager.Instance.StopBgm();
        //    AudioManager.Instance.PlayBgm(0);
        //}
    }
}
